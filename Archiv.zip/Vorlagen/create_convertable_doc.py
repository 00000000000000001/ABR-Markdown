import docx

document = docx.Document()
document.save('convertable.docx')